package avaliacao_POO;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class revendedora {

	private List<carro> ListaCarros;
	
	public revendedora() {
		ListaCarros = new ArrayList<carro>();
	}
	
	public List<carro> obterCarro(String placa){
		
		List<carro> listaPesquisaCarros = new ArrayList<carro>();
		
		for (carro a : ListaCarros) {
		if(a.getPlaca().equals(placa)) {
			return a;
						}
		return null;
		}
	}
	
		public obterValorMaior(double preco) {
			
			carro MaiorValor = null;
			LocalDate DeterminadoAno = LocalDate.now();
			
			for(carro v : ListaCarros) {
				
				if (v.getDataDeAquisicao().isBefore(DeterminadoAno)) {
					DeterminadoAno = v.getDataDeAquisicao();
					MaiorValor = v;
				}
			}

			return MaiorValor;

			}
		
			
	}
}
